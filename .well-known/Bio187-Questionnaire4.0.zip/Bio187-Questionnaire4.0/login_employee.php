<?php require_once(__DIR__ . "/partials/nav.php");?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>

<body>
    <div class="container-fluid">
        <div class="col my-5">
            <img src="bio-187-logo.png" class="img-fluid position-relative start-50 translate-middle-x"
                alt="bio-187-logo" width="800" width="200">
        </div>

        <div class="col position-relative start-50 translate-middle-x w-50">
            <form class="p-4 bg-light rounded-3 shadow-lg" method="post" action="">
                <div class="my-4">
                    <h2>Login</h2>
                </div>
                <div class="form-floating mb-3">
                    <input class="form-control" type="text" name="email" placeholder="Dummy">
                    <label class="email">Username/Email</label>
                </div>
                <div class="form-floating mb-3">
                    <input class="form-control" type="password" name="password" placeholder="Dummy">
                    <label class="">Password</label>
                </div>
                <div class="">
                    <button class="btn btn-primary" type="submit" name="login_user">Login</button>
                </div>
            </form>
        </div>
    </div>
</body>

</html>

<?php

if(isset($_POST["email"]) && isset($_POST["password"])){
    $email = se($_POST, "email", "", false);
    $password = se($_POST, "password", "", false);
    $hasError = false;
    
    
    if (str_contains($email,"@")){
        if(!is_valid_email($email)){
            $hasError = true;
        }
    } else {
        $hasError = true;
        flash("Missing Email/Username field", "danger");
    }

    if(empty($password)){
        $hasError = true;
        flash("Missing password field", "danger");
    }

    if (!is_valid_password($password)) {
        $hasError = true;
    }

    if (!$hasError){
        $db = getDB();
        $stmt = $db ->prepare("SELECT id, firstname, lastname, email, role, password from Employees 
        where email = :email");
        try{
            $r = $stmt -> execute([":email" => $email]);
            if ($r) {
                $user = $stmt -> fetch(PDO::FETCH_ASSOC);
                if ($user){
                    $hash = $user["password"]; // To be changed
                    unset($user["password"]);
                    if ($password === $hash || password_verify($password,$hash)){
                        $_SESSION["user"]["id"] = $user["id"];
                        $_SESSION["user"]["f_name"] = $user["firstname"];
                        $_SESSION["user"]["l_name"] = $user["lastname"];
                        $_SESSION["user"]["email"] = $user["email"];
                        $_SESSION["user"]["role"] = $user["role"];

                        if ($_SESSION["user"]["role"] === 'admin')
                            die(header("Location: admin/admin.php"));
                        elseif($_SESSION["user"]["role"] === 'hr')
                            die(header("Location: hr.php"));

                    } else {
                        flash("Incorrect Password", "danger");
                    }
                } else {
                    flash("Email is not found", "danger");
                }
            } 
        } catch (PDOException $e){
            echo "<pre>".var_export($e->getMessage(),true)."</pre>"; 
        }
    }
}
?>
<?php require(__DIR__ . "/partials/flash.php");?>