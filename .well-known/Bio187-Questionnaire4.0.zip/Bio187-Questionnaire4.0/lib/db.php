<?php
function getDB(){
    global $db;
    $ini= @parse_ini_file(".env");
    $url = parse_url($ini["DB_URL"]);
    $db_host= $url["host"];
    $db_user= $url["user"];
    $db_pass= $url["pass"];
    $db_name= substr($url["path"],1);
    if (!isset($db)){
        try{
            $connection_string= "mysql:host=$db_host;dbname=$db_name";
            $db = new PDO($connection_string,$db_user,$db_pass);
        }
        catch(PDOException $e){
            var_dump($e);
            $db= null;
        }
    }
    return $db;
}
?>