<?php

require_once(__DIR__."/partials/nav.php");


if (!has_role("hr")) {
    flash("You don't have permission to view this page", "warning");
    die(header("Location: " . get_url("home.php")));
}

// Checked if logged in and an HR

// This is for a test
// if (isset($_POST)) {
// 	var_export($_POST);
// }
// Validate that incoming data is true
if (isset($_POST["submit"])){
    $q_title = se($_POST, "question_title", "", false);
    $ans_type = se($_POST, "answer_type", "", false);
    $point = $_POST['point'];
    //$singlepoint = se($_POST, "singlepoint", "", false);
    $QuestionId = se($_POST, "jobId", "", false);


    $hasError = false;
    $errorLog= "";
    if(empty($q_title)){
        $hasError = true;
        $errorLog .= "Missing Question ,";
    }
    if(empty($ans_type)){
        $hasError = true;
        $errorLog .= "Missing Answer Type ,";
    }
    if(empty($point)){
        $point=(se($_POST, "singlepoint", "", false));
        if(empty($point)){
            $hasError = true;
            $errorLog .= "Missing Point(s), ";
        }
}else{
        $point =  json_encode($_POST['point']);
    }



    // Insert into database
    if(!$hasError){
        $db = getDB();
        $id = $_SESSION['user']['id'];
        $query = "INSERT INTO Questions(hr_id_q, q_title, ans_type, answers, points) 
            VALUES(:id, :q_title, :ans_type, :answers, :points)";

        $answers = json_encode($_POST['answers']); # Turn answers into json to store in db # Turn answers into json to store in db
        try{
            $stmt = $db -> prepare($query);
            $stmt -> execute([":id" => $id,':q_title' => $q_title, ':ans_type' => $ans_type, ':answers' => $answers, ':points' => $point]);
            flash("Question successfully created","success");
        }catch(PDOException $e){
            echo "<pre>".var_export($e,true)."</pre>";
        }


    // Edit Created Questions on Page!
        $hr_id = $_SESSION['user']['id'];
        $db = getDB();
        $query3 = "UPDATE Questions SET q_title = :q_title, ans_type = :ans_type, answers = :answers,
        points = :points WHERE hr_id_q = :hrId AND id = :QuestionId";

        $stmt = $db->prepare($query3);
        try{
            $stmt->execute([":q_title" => $q_title, ":ans_type" => $ans_type,':answers' => $answers, ":points" => $point, ":hrId" => $hr_id, ":QuestionId" => $QuestionId]);
            flash("Question saved successfully","success");
        } catch(PDOException $e) {

        }
    } else {;
        if ($errorLog !== "") {
            $listOfErrors = explode(',', $errorLog);
            foreach ($listOfErrors as $err) {
                if ($err != "") {
                    flash(trim($err), "info");
                }
            }
        }
    }
}

// Display Questions as they are created with a limit of 10 per page!
$db = getDB();
$questionList = array();
$id_hr = $_SESSION['user']['id'];
$query2 = "SELECT * FROM Questions WHERE hr_id_q = :id ORDER BY id DESC LIMIT 10 ";
$stmt = $db->prepare($query2);
try {
    $stmt->execute([":id" => $id_hr]);
    $questionList = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (count($questionList) == 0) {
        echo "<center><h1>No Questions Found!</h1></center>";
    }
} catch (PDOException $e) {
    echo "error";
}

?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Questionnaire Builder</title>

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

        <script>
            var y;
            var x;
            var counter;

            function Button4TextBox()
            {
                if (y == true) {
                    var x = document.createElement("INPUT");
                    x.setAttribute("type", "text");
                    document.body.appendChild(x);
                }
            }
        </script>

    </head>

    <style>
        h1 {
            text-align: center;
        }

        input {

            width: 50%;
            font-family: Times New Roman;
            font-size: 25px;
            border: 1px solid #aaaaaa;
        }

        * {
            box-sizing: border-box;
        }

        body {
            background-color: #C0DCFC;
            font-family: Times New Roman;
            font-size: 28px;
        }

        #hori {
            position: relative;
            border-radius: 10px;
            box-shadow: 0px 2px black;
            margin: 10px;
        }

        #hori {
            font-size: 24px;
            background: lightgray;
            padding: 20px;
        }

        .hide {
            width: 0;
            height: 0;
            opacity: 0;
        }

        .myBIGBOX {
            display: inline;
        }

        .myBIGBOX label{
            display:inline-block;
        }

        .myBIGBOX input{
            display:block;
        }

        .myBIGBOX button{
            display:inline;
        }
    </style>



    <body>

    <div class="container">
        <div>
            <h1>Questionnaire Creator</h1>
            <div id="hori" class="">

                <form action="" method="POST">
                    <div>
                        <div class="row">

                            <label class="big" for="q_title">Question:</label>

                            <input class="form-control" type="text" name="question_title" placeholder="What are your top 3 projects?"/>

                        </div>
                        <br>
                        <div class="form-group">
                            <label class="big" for="answer_type">Answer Type:</label>
                            <select class="form-control" name="answer_type" id="Choice">
                                <option selected value="">Select answer type</option>
                                <option value="Open Ended">Open Ended</option>
                                <option value="Y/N">Yes or No</option>
                                <option value="Multiple Choice" id="Choice">Multiple Choice</option>
                            </select>
                            <input type="text" class="hide" placeholder="Custom Choice" name='answers' id="customInput">
                            <input type="button" class="hide" value="+" onclick="addBox()" id="HidBox">
                        </div>
                        <div id="selection" class="myBIGBOX"></div>

                    </div>
                    <br>
                    <div class="row">

                        <label class="big" for="points" id='pointsLab'>Points Assigned:</label>

                        <input class="form-control" type="text" name='singlepoint' id='pointsBox' placeholder="" />

                    </div>

                    <div class="submit-btn">
                        <br>
                        <input type="submit" name="submit" style="background-color: skyblue; padding: 8px 28px; " />

                    </div>

                </form>

            </div>

        </div>
        <br>
        <!--<script>
            var counter = 1;
            var textbox = "";
            var Choice = document.getElementById('Choice');
            var customInput = document.getElementById('customInput_0');
            var selection = document.getElementById("selection");
            var HidBox = document.getElementById('HidBox');
            var pointsLab = document.getElementById('pointsLab');
            var pointsBox = document.getElementById('pointsBox');

            function addBox() {
                if (counter <= 4) {
                    var div = document.createElement("div");
                    var div2 = document.createElement("div");
                    div.setAttribute("class", "myBIGBOX");
                    div.setAttribute("id", "box_" + counter);
                    div2.setAttribute("class", "myBIGBOX");
                    div2.setAttribute("id", "box_" + counter);


                    var textBox = "<label>Answer: " + counter + "</label><input type='text' name='answers[]' placeholder='Custom Choice' class='myinput form-control myinput' id='custom_" + counter + "'><label>Points</label><input type='text' class='mybox' name='point[]'> <input class='mybox' display='inline' type='button' value='-' onclick='removeBox(this)'>";
                    //var textBox2 = "<label>Answer: " + counter + "</label><input type='text' name='answers[]' placeholder='Custom Choice' class='myinput form-control myinput' id='custom_" + counter + "'><input class='mybox' type='button' value='-' onclick='removeBox(this)'>";

                    div.innerHTML = textBox;


                    selection.appendChild(div);
                    counter++;
                }
            }



            function removeBox(ele)
            {
                ele.parentNode.remove();
                counter--;

            }

            Choice.addEventListener('change', function(){
                if(this.value == "Multiple Choice") {
                    HidBox.classList.remove('hide');
                    HidBox.classList.add('mybox');
                }
                else {
                    HidBox.classList.remove('mybox')
                    HidBox.classList.add('hide');

                }

                if(this.value == "Multiple Choice") {
                    pointsLab.classList.remove('big');
                    pointsLab.classList.add('hide');
                }
                else {
                    pointsLab.classList.remove('hide')
                    pointsLab.classList.add('big');

                }

                if(this.value == "Multiple Choice") {
                    pointsBox.classList.remove('big');
                    pointsBox.classList.add('hide');
                }
                else {
                    pointsBox.classList.remove('hide')
                    pointsBox.classList.add('big');

                }
            })
        </script>-->

        <br>
        <h1>Created Questions</h1>

        <?php if ($questionList > 0) : ?>
            <?php foreach ($questionList as $question) :
                $created = se($question, 'created', "", false);
                $created = ($created !== "") ? explode(' ', $created)[0] : "";
                ?>
                <div id="hori" class="">
                    <div class="row skills">
                        <ul>
                            Question: <li class="item"><b><?php echo $question['q_title']; ?></b></li>
                            Answer Type: <li class="item"><b><?php echo $question['ans_type']; ?></b></li>
                            Points Assigned: <li class="item"><b><?php echo $question['points']; ?></b></li>
                        </ul>
                    </div>
                    <div class="apply">
                        <a class="mr-2 mb-2 btn btn-primary btn-sm position-static edit" data-bs-toggle="modal" onclick="edit(this)" data-bs-target="#formModal">Edit</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <div class="modal fade" id="formModal" aria-labelledby="formModal" aria-hidden="true" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Question</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="model-body">
                        <form action="" method="POST" id="form1">
                            <div class="mb-2">
                                <label class="form-label" for="q_title">Question:</label>
                                <input class="form-control" type="text" name="question_title" placeholder="What are your top 3 projects?"/>
                            </div>

                            <div class="input-group mb-2">
                                <label class="form-label" for="answer_type">Answer Type:</label>
                                <select class="form-select" name="answer_type" id="Choice">
                                    <option selected value="">Select answer type</option>
                                    <option value="Open Ended">Open Ended</option>
                                    <option value="Y/N">Yes or No</option>
                                    <option value="Multiple Choice" id="Choice">Multiple Choice</option>
                                </select>
                                <input type="text" class="hide" placeholder="Custom Choice" name='answers' id="customInput">
                                <input type="button" class="hide" value="+" onclick="addBox()" id="HidBox">
                            </div>
                            <div id="selection" class="myBIGBOX"></div>

                            <div class="mb-2">
                                <label class="form-label" for="points" id='pointsLab'>Points Assigned:</label>
                                <input class="form-control" type="text" name='singlepoint' id='pointsBox' placeholder="" />
                            </div>
                            <div class="model-footer">
                                <button type="submit" form="form1" name="submit" class="btn btn-primary">Save Changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>



    </body>
    <script>
        var counter = 1;
        var textbox = "";
        var Choice = document.getElementById('Choice');
        var customInput = document.getElementById('customInput_0');
        var selection = document.getElementById("selection");
        var HidBox = document.getElementById('HidBox');
        var pointsLab = document.getElementById('pointsLab');
        var pointsBox = document.getElementById('pointsBox');

        function addBox() {
            if (counter <= 4) {
                var div = document.createElement("div");
                var div2 = document.createElement("div");
                div.setAttribute("class", "myBIGBOX");
                div.setAttribute("id", "box_" + counter);
                div2.setAttribute("class", "myBIGBOX");
                div2.setAttribute("id", "box_" + counter);


                var textBox = "<label>Answer: " + counter + "</label><input type='text' name='answers[]' placeholder='Custom Choice' class='myinput form-control myinput' id='custom_" + counter + "'><label>Points</label><input type='text' class='mybox' name='point[]'> <input class='mybox' display='inline' type='button' value='-' onclick='removeBox(this)'>";
                //var textBox2 = "<label>Answer: " + counter + "</label><input type='text' name='answers[]' placeholder='Custom Choice' class='myinput form-control myinput' id='custom_" + counter + "'><input class='mybox' type='button' value='-' onclick='removeBox(this)'>";

                div.innerHTML = textBox;


                selection.appendChild(div);
                counter++;
            }
        }



        function removeBox(ele)
        {
            ele.parentNode.remove();
            counter--;

        }

        Choice.addEventListener('change', function(){
            if(this.value == "Multiple Choice") {
                HidBox.classList.remove('hide');
                HidBox.classList.add('mybox');
            }
            else {
                HidBox.classList.remove('mybox')
                HidBox.classList.add('hide');

            }

            if(this.value == "Multiple Choice") {
                pointsLab.classList.remove('big');
                pointsLab.classList.add('hide');
            }
            else {
                pointsLab.classList.remove('hide')
                pointsLab.classList.add('big');

            }

            if(this.value == "Multiple Choice") {
                pointsBox.classList.remove('big');
                pointsBox.classList.add('hide');
            }
            else {
                pointsBox.classList.remove('hide')
                pointsBox.classList.add('big');

            }
        })
    </script>
    </html>
<?php require_once(__DIR__."/partials/flash.php");?>