<?php
require_once(__DIR__."/partials/nav.php");


if (!has_role("hr")) {
    flash("You don't have permission to view this page", "warning");
    die(header("Location: " . get_url("home.php")));
}
//$q_title = se($_POST, "question_title", "", false);
//$ans_type = se($_POST, "answer_type", "", false);
//$point = json_encode($_POST['points']);
if (isset($_POST["submit"])){
    $QuestionId = se($_POST, "jobId", "", false);

    $set_title = se($_POST, "set_title", "",false);



    $hasError = false;
    $errorLog= "";
    if(empty($set_title)){
        $hasError = true;
        $errorLog .= "Missing Title ,";
    }

    if(!$hasError){
        $db = getDB();
        //$jobpost_id = $_GET['jobId'];
        //$SelectedQuestions = array();
        $id = $_SESSION['user']['id'];
        $query = "INSERT INTO QuestionSets(set_title, question_id) 
            VALUES(:set_title, :question_id)";

        //for every question in array, input new row in table
        if(!empty($_POST['SelectedQuestions'])) {
            foreach($_POST['SelectedQuestions'] as $question_id) {
                try{
                    $stmt = $db -> prepare($query);
                    $stmt -> execute([':set_title' => $set_title, ':question_id'=> $question_id]);
                    flash("Question Set successfully created","success");
                }catch(PDOException $e){
                    echo "<pre>".var_export($e,true)."</pre>";
                }
            }
        }
        //$answers = json_encode($_POST['question_id']); # Turn questions into json to store in db # Turn answers into json to store in db
    } else {;
        $error_arr = explode(',',$errorLog);
        foreach($error_arr as $err){
            if($err != ""){
                flash($err, "warning");
                header("location: QuestionArchive.php");
                exit;
            }
        }
    }


    /*if (isset($_POST['SelectedQuestions'])) {
        print_r($_POST['SelectedQuestions']);
    }*/

//$question_id = json_encode($_POST['question_id']); # Turn questions into json to store in db # Turn answers into json to store in db

        /*try{
            $stmt = $db -> prepare($query);
            $stmt -> execute([':set_title' => $set_title, ':question_id' => $question_id]);
            flash("Question Set successfully created","success");
        }catch(PDOException $e){
            echo "<pre>".var_export($e,true)."</pre>";
        }


    } else {;
        $error_arr = explode(',',$errorLog);
        foreach($error_arr as $err){
            if($err != ""){
                flash($err, "warning");
                header("location: QuestionArchive.php");
                exit;
            }
        }

    }*/
}

$db = getDB();
$questionList = array();
$id_hr = $_SESSION['user']['id'];
$query2 = "SELECT * FROM Questions WHERE hr_id_q = :id ORDER BY id DESC LIMIT 10 ";
$stmt = $db->prepare($query2);
try {
    $stmt->execute([":id" => $id_hr]);
    $questionList = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (count($questionList) == 0) {
        echo "<center><h1>No Questions Found!</h1></center>";
    }
} catch (PDOException $e) {
    echo "error";
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Question Archive</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<style>
    h1 {
        text-align: center;
    }

    input {

        width: 50%;
        font-family: Times New Roman;
        font-size: 25px;
        border: 1px solid #aaaaaa;
    }

    * {
        box-sizing: border-box;
    }

    body {
        background-color: #C0DCFC;
        font-family: Times New Roman;
        font-size: 28px;
    }

    #hori {
        position: relative;
        border-radius: 10px;
        box-shadow: 0px 2px black;
        margin: 10px;
    }

    #hori {
        font-size: 24px;
        background: lightgray;
        padding: 20px;
    }
    body {
        margin: 10px;
        padding: 0;
    }

    header {
        background-color: white;
        border: solid 0.5px black;
        border-left: none;
        padding: 22px;
    }

    .content-body, .content-body2 {
        display: flex;
        flex-direction: column;
        border: solid 0.5px black;
        align-items: center;
        width: 80%;
        margin: 0 auto;
        margin-top: 20px;
        background-color: white;
    }

    .content-body2{
        padding-bottom: 180px;
    }


    .content-body h2 {
        margin-bottom: 20px;
    }

    .content-body form {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
    }

    .content-body form.border {
        padding: 10px;
    }

    .content-body .row {
        display: flex;
        flex-direction: column;
        margin-bottom: 10px;
    }

    .content-body .row label {
        margin-bottom: 5px;
    }

    .content-body .row input[type="text"] {
        width: calc(100% - 40px);
        padding: 5px;
        height: 40px; /* Adjusted height for the input text fields */
    }

    .content-body .row.answer-type {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
    }

    .content-body .row.answer-type .column {
        display: flex;
        flex-direction: column;
        margin-right: 10px;
    }

    .content-body .row.answer-type .column input[type="text"] {
        width: 140px;
        padding: 5px;
        margin-bottom: 5px;
    }

    .content-body .row.answer-type .column:last-child {
        margin-right: 0;
    }

    .content-body .row.answer-type .column .points-label {
        margin-bottom: 5px;
    }

    .content-body .row.answer-type .column .points-input {
        width: 40px;
    }

    .content-body .submit-btn {
        margin-top: 20px;
    }

    .options-container button {
        width: 100%;
        border: none;
        cursor: pointer;
        background-color: #fff;
        padding-top: 5px;
        padding-bottom: 8px;
    }

    .options-container button:hover {
        background-color: #ccc;
    }

    .options-container button:active {
        background-color: #aaa;
    }

    .q-row, .q-row2 {
        display: flex;
        margin-bottom: 10px;
        background-color: #d4d0d0;
        border:solid 2px black;
        border-radius: 8px;
        justify-content: center;
    }

    .q-row2{
        border: none;
    }

    .center{
        text-align: center;
        justify-content: center;
    }

    .q-row2{
        align-items: center;
        padding: 5px;
        display: flex;


    }

    .first-row{
        display: flex;
        flex-direction: column;
        width: 90%;
        margin: auto;
        background-color: #d4d0d0;
        justify-content: center;
    }

    .width{
        width: 90%;
        padding:8px;
        align-items:center ;
    }

    .border-white{
        background-color: #fff;
        border: none;
        padding: 8px;
        margin-left: 8px;
        margin-right: 25px;
        border-radius: 8px;
    }

    .small-white{
        margin-left: -25px;
        padding-left: -20px;
        background-color: #fff;
        border: none;
        height: 28px;
    }

    .q-column {
        padding: 5px;
        display: flex;
        align-items: center;
    }

    .q-button {
        padding: 5px 10px;
        background-color: slateblue;
        color:#fff;
    }

    .custom-set button{

        padding: 5px 10px;
        background-color: slateblue;
        color:#fff;

    }

    .custom-set {
        display: flex;
        flex-direction: column;
        padding-right: 48px;

    }

    .custom-set span {
        margin-right: 36px;
    }

    .dropdown-container {
        position: static;
        display: inline-block;
    }

    .dropdown-options {
        display: none;
        position: relative;
        width: auto;
        min-width: 100%;
        background-color: #fff;
        border: 1px solid #ccc;
        padding: 5px;
        box-sizing: border-box;
    }

    .dropdown-options label {
        display: inline;
        margin: 5px;
    }
</style>

<body>

    <div class="container">
        <section>
      <div class="content-body">
        <h2>Question Editor</h2>
          <?php if ($questionList > 0) : ?>
              <?php foreach ($questionList as $question) :
                  $created = se($question, 'created', "", false);
                  $created = ($created !== "") ? explode(' ', $created)[0] : "";
                  ?>
                  <div id="hori" class="">
                      <div class="row skills">
                          <ul>
                              Question: <li class="item"><b><?php echo $question['q_title']; ?></b></li>
                              Answer Type: <li class="item"><b><?php echo $question['ans_type']; ?></b></li>
                              Points Assigned: <li class="item"><b><?php echo $question['points']; ?></b></li>
                          </ul>
                      </div>
                      <div class="apply">
                          <a class="mr-2 mb-2 btn btn-primary btn-sm position-static edit" data-bs-toggle="modal" onclick="edit(this)" data-bs-target="#formModal">Edit</a>
                      </div>
                  </div>
              <?php endforeach; ?>
          <?php endif; ?>
      </div>
        </section>
        <section>
            <form action="" method="POST">
          <div class="content-body2">
            <h2>Question Set Creator</h2>
            <div class = "first-row">
            <div class="q-row2">
              <div class="q-column">
                <label for="title">Title:</label>
                <input name='set_title' class="border-white" type="text" id="title" placeholder="">
              </div>

              <div class="dropdown-container">
                  <label for="title">Select:</label>
                  <button class="small-white" id="dropdownButton">▼</button>
                  <div class="dropdown-options">
                      <?php if ($questionList > 0) : ?>
                        <?php foreach ($questionList as $question) :
                            $created = se($question, 'created', "", false);
                            $created = ($created !== "") ? explode(' ', $created)[0] : "";
                             ?>
                              <label for="option1"><input type="checkbox" id="option1" name="SelectedQuestions[]" value="<?php echo $question['id'];?>"><li class="item"><b><?php echo $question['id'], $question['q_title']; ?></b></li></label>
                              <!--<label for="option2"><input type="checkbox" id="option2" name="selectButton" value="What are your best questions"> What are your best questions</label>
                              <label for="option3"><input type="checkbox" id="option3" name="selectButton" value="What are your best questions"> What are your best questions</label>
                              <label for="option4"><input type="checkbox" id="option4" name="selectButton" value="What are your best questions"> What are your best questions</label>
                              <label for="option5"><input type="checkbox" id="option5" name="selectButton" value="What are your best questions"> What are your best questions</label>-->
                          <?php endforeach; ?>
                      <?php endif; ?>
                  </div>
              </div>

            </div>
            <div class="q-row2 center">
              <div class="q-column">
                <p>Click to create a custom Set:</p>
              </div>
              <div class="q-column">
                <button name="submit" class="q-button" type="submit" onclick="createSet()">Create</button>
              </div>
            </form>
            </div>

            <h2>Created Question Sets</h2>
            <div class="q-row width">
              <div id="customSet" class="custom-set"></div>
                <div class="q-column">
                <p class = "blue" id="customSetText"></p>
              </div>
            </div>
        </section>
    </div>
</body>
<script>

    function toggleOptions() {
        var optionsContainer = document.getElementById("optionsContainer");
        optionsContainer.classList.toggle("show");
    }

    function openEditScreen(rowIndex) {
        document.getElementById(`editScreen${rowIndex}`).style.display = 'flex';

        // Populate the edit screen with existing values from the selected row
        document.getElementById(`editQuestion${rowIndex}`).value = document.getElementById(`question${rowIndex}`).value;
        document.getElementById(`editAnswerType${rowIndex}`).value = document.getElementById(`answerType${rowIndex}`).value;
        document.getElementById(`editPoints${rowIndex}`).value = document.getElementById(`points${rowIndex}`).value;
    }

    function closeEditScreen(rowIndex) {
        document.getElementById(`editScreen${rowIndex}`).style.display = 'none';
    }

    function saveChanges(rowIndex) {
        // Update the original values with the edited values
        document.getElementById(`question${rowIndex}`).value = document.getElementById(`editQuestion${rowIndex}`).value;
        document.getElementById(`answerType${rowIndex}`).value = document.getElementById(`editAnswerType${rowIndex}`).value;
        document.getElementById(`points${rowIndex}`).value = document.getElementById(`editPoints${rowIndex}`).value;
        closeEditScreen(rowIndex);
    }

    function createSet() {
        const title = document.getElementById('set_title').value;
        const checkboxes = document.querySelectorAll('input[name="SelectedQuestions[]"]:checked');
        const selectedOptionsCount = checkboxes.length;

        const customSetSection = document.getElementById('customSet');

        const setElement = document.createElement('div');
        setElement.classList.add('set');

        const titleElement = document.createElement('span');
        titleElement.textContent = 'Title: ';
        setElement.appendChild(titleElement);

        const setTitleElement = document.createElement('span');
        setTitleElement.textContent = title;
        setElement.appendChild(setTitleElement);

        const numQuestionsElement = document.createElement('span');
        numQuestionsElement.textContent = ' Number of Questions: ';
        setElement.appendChild(numQuestionsElement);

        const setCountElement = document.createElement('span');
        setCountElement.textContent = selectedOptionsCount;
        setElement.appendChild(setCountElement);

        const editButton = document.createElement('button');
        editButton.textContent = 'Edit';
        editButton.addEventListener('click', () => {
            // Handle edit functionality
            // You can access the title, selected options count, and perform necessary actions
        });
        setElement.appendChild(editButton);

        customSetSection.appendChild(setElement);

        // Clear the fields
        document.getElementById('title').value = '';
        checkboxes.forEach(checkbox => {
            checkbox.checked = false;
        });

        // Change layout to column
        customSetSection.classList.remove('row');
    }

    document.getElementById('dropdownButton').addEventListener('click', function(event) {
        event.preventDefault();
        var dropdownOptions = document.querySelector('.dropdown-options');
        dropdownOptions.style.display = dropdownOptions.style.display === 'block' ? 'none' : 'block';
    });

    document.getElementById('textInput').addEventListener('input', function() {
        var inputWidth = this.offsetWidth + 'px';
        document.querySelector('.dropdown-options').style.minWidth = inputWidth;
    });
</script>

</html>
<?php require_once(__DIR__."/partials/flash.php");?>